import static org.junit.Assert.*;

public class TicTacToeModelTest {

  @org.junit.Test
  public void move() {
  }

  @org.junit.Test
  public void getTurn() {
  }

  @org.junit.Test
  public void isGameOver() {
  }

  @org.junit.Test
  public void getWinner() {
  }

  @org.junit.Test
  public void getBoard() {
  }

  @org.junit.Test
  public void getMarkAt() {
  }

  @org.junit.Test
  public void testToString() {
  }
}